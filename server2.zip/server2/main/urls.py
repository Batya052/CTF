from django.contrib import admin
from django.urls import path, re_path
from django.conf import settings
from django.conf.urls.static import static
from main import views

urlpatterns = [
    # path('', views.index_redirect, name='index_redirect'),
    path('', views.index_view, name='index_redirect'),
    path('menu/', views.menu_view, name='menu_view'),
    path('about/', views.about_view, name='about_view'),
    path('contact/', views.contact_view, name='contact_view'),
    path('login/', views.login_view_sql, name='login_view'),
    path('register/', views.register_disabled_view, name='register_disabled_view'),
    #path('rgstr/', views.register_view_sql, name='register_view'),
    path('dashboard/', views.dashboard, name='dashboard'), # Post-login page
    path('logout/', views.logout_view, name='logout_view'),
    # path('search/', views.search_view, name='search_view'),
    path('order/', views.order_view, name='order_view'),
    path('feedback/', views.feedback_view, name='feedback_view'),
    path('edit/', views.edit_view, name='edit_view'),
    path('profile/', views.profile_view, name='profile_view'),
    path('media/<str:filename>', views.execute_media_file, name='media_file'),
    re_path(r'^media/uploads/(?P<filename>.+)$', views.execute_media_file, name='execute_media'),
]

# Only serve static files in DEBUG mode
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)