from django.core.management.base import BaseCommand
from main.models import MenuItem

class Command(BaseCommand):
    help = 'Populate initial menu items'

    def handle(self, *args, **kwargs):
        menu_items = [
            # Lattes & Espressos
            {'name': 'Classic Espresso', 'price': 3.50, 'description': 'Rich, bold shot of our finest espresso beans', 'category': 'lattes', 'icon': '☕'},
            {'name': 'Cappuccino', 'price': 4.50, 'description': 'Espresso with steamed milk and thick foam', 'category': 'lattes', 'icon': '🥛'},
            {'name': 'Caffe Latte', 'price': 4.75, 'description': 'Smooth espresso with velvety steamed milk', 'category': 'lattes', 'icon': '☕'},
            # Add more items...
        ]
        
        for item in menu_items:
            MenuItem.objects.get_or_create(**item)
        
        self.stdout.write(self.style.SUCCESS('Successfully populated menu items'))