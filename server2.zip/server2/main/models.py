# main/models.py

from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth.models import AbstractUser


class SystemTemplate(models.Model):
    """
    Simulated model for the system_templates table used for the Blind SQLi vulnerability.
    """
    name = models.CharField(max_length=255, unique=True)
    
    # Optional: A few dummy fields to make the database look more real
    content_path = models.CharField(max_length=255, default='path/to/template.html')

    class Meta:
        # Crucially, this defines the exact table name expected by the SQLi query
        db_table = 'system_templates' 
        verbose_name = 'System Template'
        verbose_name_plural = 'System Templates'

    def __str__(self):
        return self.name
    
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    name = models.CharField(max_length=255, blank=True, default='')
    position = models.CharField(max_length=255, blank=True, default='')
    address = models.CharField(max_length=255, blank=True, default='')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.user.username}'s Profile"

class CreditCard(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='credit_cards')
    card_name = models.CharField(max_length=100)  # e.g., "card1", "Visa Main"
    card_number = models.CharField(max_length=19)  # Format: 1234-5678-9012-3456
    expiry_date = models.CharField(max_length=7)   # Format: MM/YYYY
    cvv = models.CharField(max_length=4)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.card_name}"
    
    class Meta:
        ordering = ['-created_at']

class Order(models.Model):
    STATUS_CHOICES = [
        ('waiting', 'Waiting'),
        ('preparing', 'Preparing'),
        ('ready', 'Ready'),
        ('delivered', 'Delivered'),
        ('cancelled', 'Cancelled'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders')
    code = models.CharField(max_length=50, unique=True)
    details = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='waiting')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"Order {self.code} - {self.user.username}"
    
    class Meta:
        ordering = ['-created_at']



class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='feedbacks')
    feedback_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.user.username} - {self.created_at.strftime('%Y-%m-%d')}"
    
    class Meta:
        ordering = ['-created_at']


class MenuItem(models.Model):
    CATEGORY_CHOICES = [
        ('lattes', 'Lattes & Espressos'),
        ('ice', 'On Ice'),
        ('blended', 'Blended'),
        ('brewed', 'Brewed Coffees & Teas'),
        ('tea_lattes', 'Tea Lattes'),
        ('chocolates', 'Chocolates Chauds'),
        ('smoothies', 'Smoothies'),
        ('food', 'Food'),
    ]
    
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=5, decimal_places=2)
    description = models.TextField()
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    icon = models.CharField(max_length=10, default='☕')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.name} - ${self.price}"
    
    class Meta:
        ordering = ['category', 'name']