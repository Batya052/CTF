from django.shortcuts import render, redirect
from django.contrib.auth.models import User, AnonymousUser 
from django.views.decorators.http import require_http_methods
from django.http import HttpResponseRedirect
from django.http import HttpResponseForbidden
from django.http import HttpResponse, HttpResponseForbidden, HttpResponseNotFound
from django.db import connection , DatabaseError
import time
from django.contrib.auth.hashers import make_password, check_password
from rest_framework_simplejwt.tokens import RefreshToken, AccessToken 
from django.utils import timezone
from rest_framework_simplejwt.tokens import AccessToken as BaseAccessToken
from rest_framework_simplejwt.tokens import RefreshToken as BaseRefreshToken
from django.template import Template, Context # <-- Add this import!
from django.utils.safestring import mark_safe # <-- Add this import!
from django.conf import settings
import os
from django.contrib.messages.storage import base # Required for the base storage class
from django.core.signing import Signer # Required for the Signer class
import imghdr
from PIL import Image
from io import BytesIO
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.http import JsonResponse  # Add this import
from django.contrib.auth import authenticate
from django.core.cache import cache
from django.utils import timezone
from datetime import timedelta



# Keep necessary imports, remove unused ones:
# from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout

# --- Custom Token Classes (Final Clean Version) ---
class VulnerableAccessToken(BaseAccessToken):
    # CRITICAL: We only use this tuple to stop unwanted claims from being copied.
    # We RELY on the BaseAccessToken to correctly set 'token_type' to "access".
    no_copy_claims = ('jti', 'user_id',) 

    @classmethod
    def for_user(cls, user):
        token = super().for_user(user)
        
        # 1. Ensure user_id and jti are deleted from the payload
        if 'user_id' in token:
            del token['user_id']
        if 'jti' in token:
            del token['jti']
            
        # 2. Add the attack vector
        token['sub'] = user.username
        
        return token

class VulnerableRefreshToken(BaseRefreshToken):
    access_token_class = VulnerableAccessToken
    no_copy_claims = ('jti', 'user_id',) 

    @classmethod
    def for_user(cls, user):
        token = super().for_user(user)
        
        # Ensure user_id and jti are deleted
        if 'user_id' in token:
            del token['user_id']
        if 'jti' in token:
            del token['jti']
        
        token['sub'] = user.username
        
        return token


#--- Helper Function for JWT Token Generation (Guaranteed Clean Payload) ---
def get_tokens_for_user(user):
    """
    Generates tokens, removes 'user_id', 'jti', and any leftover UUID ID claims 
    ('null') to guarantee a clean payload with only 'sub'.
    """
    refresh = RefreshToken.for_user(user)
    access = refresh.access_token 
    
    payload = access.payload

    # 1. Delete standard claims we hate
    if 'user_id' in payload:
        del payload['user_id']
    if 'jti' in payload:
        del payload['jti']
    if 'null' in payload:  # Deletes the ghost key
        del payload['null']

    # 2. CRITICAL: Identify and delete any remaining claims that look like a UUID
    # This addresses cases where the claim name is unexpected.
    keys_to_delete = []
    
    for key, value in payload.items():
        # Check if the key is not one of the mandatory/allowed keys
        if key not in ['token_type', 'exp', 'iat', 'sub']:
            # Check if the value is a string and looks like a UUID (length 32 or 36)
            if isinstance(value, str) and (len(value) == 32 or len(value) == 36):
                keys_to_delete.append(key)

    for key in keys_to_delete:
        del payload[key]

    # 3. Add the 'sub' claim (The attack vector)
    payload['sub'] = user.username
    
    # The token is automatically re-signed when converting back to a string
    return {
        'refresh': str(refresh),
        'access': str(access),
    }


# --- Custom JWT Decorator (Replaces @login_required) ---
def jwt_required(view_func):
    """
    Checks for a valid 'access_token' cookie and authenticates the user 
    by looking up the user via the 'sub' (Subject/Username) claim.
    """
    def wrapper(request, *args, **kwargs):
        token_str = request.COOKIES.get('access_token')
        login_url = '/login'

        if not token_str:
            return HttpResponseRedirect(login_url) 
        
        try:
            token = AccessToken(token_str)
            
            # CRITICAL CHANGE: Extract username from the 'sub' claim
            username = token.get('sub')
            
            if not username:
                # If the 'sub' claim is missing, the token is invalid for this system
                raise Exception("Token missing 'sub' claim.")
            
            # 2. Load the user based on the username from the token
            user = User.objects.get(username=username, is_active=True)
            request.user = user
            
            # 3. Return the view result
            return view_func(request, *args, **kwargs)
            
        except User.DoesNotExist:
            print(f"JWT Authentication Error: User '{username}' does not exist.") 
            response = HttpResponseRedirect(login_url)
            response.delete_cookie('access_token')
            return response
            
        except Exception as e:
            # Handles expired token, invalid signature, etc.
            print(f"JWT Authentication Error: {e}") 
            response = HttpResponseRedirect(login_url)
            response.delete_cookie('access_token')
            return response
            
    return wrapper

# --------------------------------------------------------

## 1. Homepage Redirect View

# @require_http_methods(["GET"])
# def index_redirect(request):
#     """
#     Redirects baris.org/ to baris.org/login
#     """
#     return redirect('login_view')






@require_http_methods(["GET", "POST"]) # Allow both GET and POST for robustness
def register_disabled_view(request):
    """
    Returns a plain text response indicating that registration is currently unavailable.
    """
    time.sleep(1) 
    
    message = "We apologize, but there was a problem with registration. Please try again later, or contact support for assistance."
    
    # Return a simple text response with a 503 Service Unavailable status code
    # to better communicate the issue to clients and search engines.
    return HttpResponse(message, status=503)


## 2. User Registration View (/rgstr)

@require_http_methods(["GET", "POST"])
def register_view_sql(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        raw_password = request.POST.get('password')
        
        hashed_password = make_password(raw_password)
        current_time = timezone.now()
        
        default_email = ''
        default_first_name = ''
        default_last_name = ''
        
        try:
            with connection.cursor() as cursor:
                sql = """
                    INSERT INTO auth_user (
                        username, password, date_joined, 
                        is_active, is_superuser, is_staff, 
                        email, first_name, last_name, last_login 
                    )
                    VALUES (%s, %s, %s, TRUE, FALSE, FALSE, %s, %s, %s, %s);
                """
                
                cursor.execute(sql, [
                    username, 
                    hashed_password, 
                    current_time,  
                    default_email, 
                    default_first_name, 
                    default_last_name, 
                    current_time   
                ])
                
            return HttpResponseRedirect('/login')
            
        except Exception as e:
            print(f"Database Error during registration: {e}") 
            return render(request, 'rgstr.html', {'error': 'Registration failed. Username may already be taken.'})

    return render(request, 'rgstr.html')



## 3. User Login View (/login)

@require_http_methods(["GET", "POST"])
def login_view_sql(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        raw_password = request.POST.get('password')
        
        # Rate limiting for admin user
        if username and username.lower() == 'admin':
            cache_key = f'login_attempts_admin'
            lockout_key = f'login_lockout_admin'
            
            # Check if admin is locked out
            if cache.get(lockout_key):
                lockout_time = cache.get(lockout_key)
                remaining_time = 60 - (timezone.now().timestamp() - lockout_time)
                if remaining_time > 0:
                    return render(request, 'login.html', {
                        'error': f'Too many failed attempts. Please wait {int(remaining_time)} seconds.'
                    })
                else:
                    # Lockout expired, clear both keys
                    cache.delete(lockout_key)
                    cache.delete(cache_key)
            
            # Get current attempt count
            attempts = cache.get(cache_key, 0)
            
            # Check if already at max attempts
            if attempts >= 3:
                # Set lockout for 60 seconds
                cache.set(lockout_key, timezone.now().timestamp(), 60)
                cache.delete(cache_key)
                return render(request, 'login.html', {
                    'error': 'Too many failed attempts. Please wait 1 minute.'
                })
        
        hashed_password_from_db = None
        user_id = None
        
        with connection.cursor() as cursor:
            sql = "SELECT id, password FROM auth_user WHERE username = %s AND is_active = TRUE;"
            cursor.execute(sql, [username])
            row = cursor.fetchone()
            
            if row:
                user_id, hashed_password_from_db = row
        
        if hashed_password_from_db and check_password(raw_password, hashed_password_from_db):
            # Successful login - clear rate limiting for admin
            if username and username.lower() == 'admin':
                cache.delete(f'login_attempts_admin')
                cache.delete(f'login_lockout_admin')
            
            user = User.objects.get(id=user_id)
            
            # Generate and set JWT token
            tokens = get_tokens_for_user(user)
            
            response = HttpResponseRedirect('/dashboard')
            response.set_cookie(
                key='access_token',
                value=tokens['access'],
                httponly=True,
            )
            return response
        else:
            # Failed login - increment attempts for admin
            if username and username.lower() == 'admin':
                cache_key = f'login_attempts_admin'
                attempts = cache.get(cache_key, 0)
                attempts += 1
                cache.set(cache_key, attempts, 70)  # 60s lockout + 10s buffer
                
                remaining = 3 - attempts
                if remaining > 0:
                    return render(request, 'login.html', {
                        'error': f'Invalid credentials. {remaining} attempt(s) remaining.'
                    })
            
            return render(request, 'login.html', {'error': 'Invalid credentials.'})

    return render(request, 'login.html')



## 4. User Dashboard View (/dashboard)

@jwt_required 
def dashboard(request):
    # The user object is loaded via the 'sub' claim from the JWT.
    return render(request, 'dashboard.html', {'user': request.user})



## 5. User Logout View (/logout)

@require_http_methods(["GET", "POST"])
def logout_view(request):
    response = redirect('login_view')
    response.delete_cookie('access_token') 
    return response





def execute_raw_sql(query):
    """
    DANGEROUS: Executes raw SQL. This is where the vulnerability lives.
    """
    try:
        with connection.cursor() as cursor:
            # We don't care about the result, only the delay (Blind SQLi setup)
            cursor.execute(query)
            return True
    except DatabaseError as e:
        print(f"SQL Error: {e}")
        return False
# --- END SIMULATION ---


#Edit part

@jwt_required
@require_http_methods(["GET", "POST"])
def edit_view(request):
    """
    Admin-only view vulnerable to Blind Time-Based SQLi via the item_name input.
    Allows admin to search, add, edit, and delete menu items.
    """
    if request.user.username != 'admin':
        return HttpResponseForbidden("Access Denied: You must be the 'admin' to edit menu.")

    from .models import MenuItem
    
    edit_message = ""
    item_name = ""
    search_results = []
    all_items = MenuItem.objects.all()

    # Handle DELETE request
    if request.method == 'POST' and 'delete_item_id' in request.POST:
        try:
            item_id = request.POST.get('delete_item_id')
            item = MenuItem.objects.get(id=item_id)
            item_name_deleted = item.name
            item.delete()
            return JsonResponse({
                'success': True,
                'message': f'Menu item "{item_name_deleted}" deleted successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })

    # Handle ADD/UPDATE request
    if request.method == 'POST' and 'item_name' in request.POST and 'item_price' in request.POST:
        try:
            item_id = request.POST.get('item_id', '').strip()
            item_name = request.POST.get('item_name', '').strip()
            item_price = request.POST.get('item_price', '').strip()
            item_description = request.POST.get('item_description', '').strip()
            item_category = request.POST.get('item_category', '').strip()
            item_icon = request.POST.get('item_icon', '☕').strip()
            
            if item_id:  # Update existing
                item = MenuItem.objects.get(id=item_id)
                item.name = item_name
                item.price = item_price
                item.description = item_description
                item.category = item_category
                item.icon = item_icon
                item.save()
                message = f'Menu item "{item_name}" updated successfully!'
            else:  # Create new
                MenuItem.objects.create(
                    name=item_name,
                    price=item_price,
                    description=item_description,
                    category=item_category,
                    icon=item_icon
                )
                message = f'Menu item "{item_name}" added successfully!'
            
            return JsonResponse({
                'success': True,
                'message': message
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })

    # Handle SEARCH request (VULNERABLE TO SQL INJECTION)
    if request.method == 'POST' and 'search_item' in request.POST:
        item_name = request.POST.get('search_item', '').strip()
        
        # 🚨 VULNERABLE SQL QUERY CONSTRUCTION
        # Direct string concatenation without parameterization
        sql_query = f"SELECT id, name, price, description, category, icon FROM main_menuitem WHERE name LIKE '%{item_name}%'"
        
        # 🚨 EXECUTE VULNERABLE CODE (Blind SQLi timing attack possible)
        start_time = time.time()
        try:
            with connection.cursor() as cursor:
                cursor.execute(sql_query)
                rows = cursor.fetchall()
                search_results = [
                    {
                        'id': row[0],
                        'name': row[1],
                        'price': row[2],
                        'description': row[3],
                        'category': row[4],
                        'icon': row[5]
                    }
                    for row in rows
                ]
        except Exception as e:
            edit_message = f"Search Error: {str(e)}"
            search_results = []
        
        end_time = time.time()
        query_duration = end_time - start_time
        
        # CONDITIONAL RESPONSE for Blind SQLi
        if query_duration > 1.0:
            edit_message = f"**Search Delayed:** Query took {query_duration:.3f}s. Check system logs."
        else:
            edit_message = f"Found {len(search_results)} item(s)."

    return render(request, 'edit.html', {
        'username': request.user.username,
        'edit_message': edit_message,
        'item_name': item_name,
        'search_results': search_results,
        'all_items': all_items,
        'categories': MenuItem.CATEGORY_CHOICES
    })



#File upload part
import json
from django.db import models


MEDIA_ROOT = 'media/uploads'  # Adjust to your media folder path



@jwt_required
@require_http_methods(["GET", "POST"])
def profile_view(request):
    """
    Handles file upload with intentionally weak validation.
    VULNERABILITY 1: Uses imghdr which only checks magic bytes.
    VULNERABILITY 2: Preserves original filename without sanitization.
    """
    # 1. Handle admin password verification (AJAX request) - FIRST
    if request.method == 'POST' and 'verify_password' in request.POST:
        password = request.POST.get('verify_password')
        user = authenticate(username=request.user.username, password=password)
        
        if user is not None:
            request.session['admin_verified'] = True
            return JsonResponse({'success': True})
        else:
            return JsonResponse({'success': False, 'error': 'Incorrect password'})
    
    # 2. Handle credit card save (AJAX) - SECOND (MOVED UP!)
    if request.method == 'POST' and 'card_name' in request.POST:
        try:
            from .models import CreditCard 
            
            card_name = request.POST.get('card_name', '').strip()
            card_number = request.POST.get('card_number', '').strip().replace('-', '') 
            expiry_date = request.POST.get('expiry_date', '').strip()
            cvv = request.POST.get('cvv', '').strip()
            
            print(f"DEBUG: Attempting to save card - {card_name}")
            
            if not all([card_name, card_number, expiry_date, cvv]):
                return JsonResponse({
                    'success': False,
                    'error': 'All credit card fields are required'
                })
            
            CreditCard.objects.create(
                user=request.user,
                card_name=card_name,
                card_number=card_number,
                expiry_date=expiry_date,
                cvv=cvv
            )
            
            print(f"DEBUG: Card saved successfully - {card_name}")
            
            return JsonResponse({
                'success': True,
                'message': f'Credit card "{card_name}" saved successfully!'
            })
        
        except Exception as e:
            print(f"DEBUG: Error saving card - {str(e)}")
            return JsonResponse({
                'success': False,
                'error': f'Failed to save card: {str(e)}'
            })
    
    # 3. Handle credit card deletion (AJAX) - THIRD
    if request.method == 'POST' and 'delete_card_id' in request.POST:
        try:
            from .models import CreditCard
            
            card_id = request.POST.get('delete_card_id')
            card = CreditCard.objects.get(id=card_id, user=request.user)
            card.delete()
            
            return JsonResponse({
                'success': True,
                'message': 'Credit card deleted successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    # 4. Handle AJAX save profile data - FOURTH (MOVED DOWN!)
    if request.method == 'POST' and request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        try:
            from django.contrib.auth.models import User
            from .models import UserProfile
            
            profile, created = UserProfile.objects.get_or_create(user=request.user)
            
            name = request.POST.get('name', '').strip()
            position = request.POST.get('position', '').strip()
            address = request.POST.get('address', '').strip()
            
            if name:
                profile.name = name
            if position:
                profile.position = position
            if address:
                profile.address = address
            
            profile.save()
            
            return JsonResponse({
                'success': True,
                'message': 'Profile information saved successfully!'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    # Check if admin user and not verified yet
    if request.user.username == 'admin' and not request.session.get('admin_verified', False):
        current_pic_url = get_profile_picture_url(request)
        return render(request, 'profile.html', {
            'username': getattr(request.user, 'username', 'guest'),
            'message': "Please verify your password to access profile settings",
            'current_pic_url': current_pic_url,
            'show_verification': True
        })
    
    # Handle file upload
    if request.method == 'POST' and 'profile_pic' in request.FILES:
        uploaded_file = request.FILES['profile_pic']
        original_filename = uploaded_file.name
        
        file_extension = os.path.splitext(original_filename)[1]
        file_data = uploaded_file.read()
        
        # 🚨 VULNERABILITY 1: WEAK IMAGE VALIDATION
        if imghdr.what(None, h=file_data) is None:
            current_pic_url = get_profile_picture_url(request)
            return render(request, 'profile.html', {
                'username': getattr(request.user, 'username', 'guest'),
                'message': "Error: File is not a valid image.",
                'current_pic_url': current_pic_url,
                'show_verification': False
            })
        
        new_filename = generate_unique_filename(file_extension)
        
        # 🚨 VULNERABILITY 2: UNSAFE FILENAME HANDLING
        if not os.path.exists(MEDIA_ROOT):
            os.makedirs(MEDIA_ROOT)
        
        file_path = os.path.join(MEDIA_ROOT, new_filename)
        
        with open(file_path, 'wb') as destination:
            destination.write(file_data)
        
        request.session['profile_picture'] = new_filename
        
        print(f"DEBUG: File uploaded - {new_filename}")
        
        return render(request, 'profile.html', {
            'username': getattr(request.user, 'username', 'guest'),
            'message': f"Profile picture uploaded! Saved as: /media/uploads/{new_filename}",
            'current_pic_url': f'/media/uploads/{new_filename}',
            'show_verification': False
        })
    
    # GET request - Load user data
    current_pic_url = get_profile_picture_url(request)
    
    try:
        from .models import UserProfile, CreditCard, Order
        
        profile = UserProfile.objects.filter(user=request.user).first()
        user_name = profile.name if profile else ''
        user_position = profile.position if profile else ''
        user_address = profile.address if profile else ''
        
        credit_cards = CreditCard.objects.filter(user=request.user).order_by('-created_at')
        orders = Order.objects.filter(user=request.user, status='waiting').order_by('-created_at')
        
    except Exception as e:
        print(f"Error loading profile data: {e}")
        user_name = ''
        user_position = ''
        user_address = ''
        credit_cards = []
        orders = []
    
    print(f"DEBUG: GET request - current_pic_url: {current_pic_url}")
    
    return render(request, 'profile.html', {
        'username': getattr(request.user, 'username', 'guest'),
        'message': "Upload your profile picture",
        'current_pic_url': current_pic_url,
        'show_verification': False,
        'user_name': user_name,
        'user_position': user_position,
        'user_address': user_address,
        'credit_cards': credit_cards,
        'orders': orders
    })

def generate_unique_filename(extension):
    """
    Generate unique filename in format: picture_{number}.{extension}
    Finds the next available number by checking existing files.
    """
    counter = 1
    while True:
        filename = f"picture_{counter}{extension}"
        file_path = os.path.join(MEDIA_ROOT, filename)
        
        # Check if file exists
        if not os.path.exists(file_path):
            return filename
        
        counter += 1
        
        # Safety check to prevent infinite loop
        if counter > 10000:
            # Fallback to timestamp-based name
            import time
            return f"picture_{int(time.time())}{extension}"


def get_profile_picture_url(request):
    """
    Helper function to get the correct profile picture URL from session.
    """
    # Get profile picture from session
    profile_pic = request.session.get('profile_picture', None)
    
    print(f"DEBUG: Session profile_picture: {profile_pic}")
    
    # Check if profile_pic exists and is not empty
    if profile_pic and profile_pic.strip():
        # Check if the file actually exists
        file_path = os.path.join(MEDIA_ROOT, profile_pic)
        if os.path.exists(file_path):
            url = f'/media/uploads/{profile_pic}'
            print(f"DEBUG: Returning uploaded pic URL: {url}")
            return url
    
    # No profile picture set or file doesn't exist, use default from static
    print(f"DEBUG: Returning default pic")
    return '/static/default_pic.png'


@require_http_methods(["GET"])
def execute_media_file(request, filename):
    """
    🚨 CRITICAL VULNERABILITY: Executes code from image metadata
    
    Simulates a misconfigured server that extracts and executes
    PHP/Python code stored in image EXIF Comment fields.
    """
    # Filename already includes just the file (e.g., "picture_1.py")
    # MEDIA_ROOT already points to media/uploads/
    file_path = os.path.join(MEDIA_ROOT, filename)

    if not os.path.exists(file_path):
        return HttpResponseNotFound(f"File not found: {filename}")
    
    # Check if file has executable extension
    if filename.lower().endswith(('.php', '.py', '.html')):
        try:
            # Open the polyglot image
            img = Image.open(file_path)
            
            # 🚨 EXTRACT PAYLOAD FROM EXIF COMMENT FIELD
            # This is where the polyglot's hidden code resides
            comment_payload = img.info.get('comment', '')
            
            # Handle both string and bytes
            if isinstance(comment_payload, bytes):
                comment_payload = comment_payload.decode('utf-8', errors='ignore')
            
            if not comment_payload:
                # No payload found, return image data
                with open(file_path, 'rb') as f:
                    return HttpResponse(
                        f.read(), 
                        content_type=f'image/{img.format.lower() if img.format else "jpeg"}'
                    )

            # 🚨 RCE VULNERABILITY: Execute Python code from comment
            try:
                # Create a namespace to capture output
                import sys
                from io import StringIO
                
                # Capture stdout
                old_stdout = sys.stdout
                sys.stdout = captured_output = StringIO()
                
                # Execute the Python payload
                exec(comment_payload)
                
                # Get the output
                sys.stdout = old_stdout
                output = captured_output.getvalue()
                
                if output:
                    return HttpResponse(f"<pre>{output}</pre>")
                else:
                    return HttpResponse("Executed successfully (no output)")
                    
            except Exception as e:
                sys.stdout = old_stdout
                return HttpResponse(f"Execution Error: {str(e)}", status=500)

        except Exception as e:
            return HttpResponse(f"File Processing Error: {str(e)}", status=500)
    
    else:
        # Serve non-executable files normally
        import mimetypes
        content_type, _ = mimetypes.guess_type(filename)
        if content_type is None:
            content_type = "image/jpeg"
        with open(file_path, 'rb') as f:
            return HttpResponse(f.read(), content_type=content_type)
        





##############################

def get_user_from_jwt_cookie(request):
    """
    Helper function to extract user from JWT cookie for template rendering.
    Returns the User object if authenticated, None otherwise.
    """
    token_str = request.COOKIES.get('access_token')
    
    if not token_str:
        return None
    
    try:
        token = AccessToken(token_str)
        username = token.get('sub')
        
        if username:
            user = User.objects.get(username=username, is_active=True)
            return user
    except:
        pass
    
    return None



#########################################     Directories        #######################################


@require_http_methods(["GET"])
def index_view(request):
    """
    Renders the index.html template.
    """
    user = get_user_from_jwt_cookie(request)
    return render(request, 'index.html', {'user': user})


# @jwt_required
@require_http_methods(["GET"])
def menu_view(request):
    from .models import MenuItem
    
    user = get_user_from_jwt_cookie(request)
    
    # Group items by category
    items_by_category = {}
    for category_value, category_label in MenuItem.CATEGORY_CHOICES:
        items_by_category[category_value] = MenuItem.objects.filter(category=category_value)
    
    return render(request, 'menu.html', {
        'user': user,
        'items_by_category': items_by_category
    })

@require_http_methods(["GET"])
def about_view(request):
    """
    Renders the about.html template.
    """
    user = get_user_from_jwt_cookie(request)
    return render(request, 'about.html', {'user': user})

@require_http_methods(["GET"])
def contact_view(request):
    """
    Renders the contact.html template.
    """
    user = get_user_from_jwt_cookie(request)
    return render(request, 'contact.html', {'user': user})



@jwt_required
@require_http_methods(["POST", "GET"])
def feedback_view(request):
    """
    Handles feedback submission and display.
    """
    from .models import Feedback, UserProfile
    
    user = get_user_from_jwt_cookie(request)
    
    if request.method == 'POST':
        feedback_text = request.POST.get('feedback', '').strip()
        
        # Validate feedback length
        if len(feedback_text) < 30:
            return JsonResponse({
                'success': False,
                'error': 'Feedback must be at least 30 characters long.'
            })
        
        try:
            # Save feedback to database
            Feedback.objects.create(
                user=user,
                feedback_text=feedback_text
            )
            
            return JsonResponse({
                'success': True,
                'message': 'Thank you! Your feedback has been submitted successfully.'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': f'Failed to save feedback: {str(e)}'
            })
    
    # GET request - Load user feedbacks
    try:
        # Get user profile for display
        profile = UserProfile.objects.filter(user=user).first()
        user_name = profile.name if profile else f"{user.first_name} {user.last_name}"
        user_position = profile.position if profile else 'Customer'
        
        # Get user's feedbacks
        feedbacks = Feedback.objects.filter(user=user).order_by('-created_at')
        
    except Exception as e:
        print(f"Error loading feedback data: {e}")
        user_name = user.username
        user_position = 'Customer'
        feedbacks = []
    
    return render(request, 'feedback.html', {
        'user': user,
        'user_name': user_name,
        'user_position': user_position,
        'feedbacks': feedbacks
    })


@jwt_required
@require_http_methods(["POST", "GET"])
def order_view(request):
    from .models import Order, CreditCard
    import random
    import string
    
    if request.method == 'POST':
        product_name = request.POST.get('product_name', '').strip()
        delivery_method = request.POST.get('delivery_method', '')
        payment_method = request.POST.get('payment_method', '')
        
        # Initialize order_message
        order_message = ''
        
        is_admin_user = (request.user.username == 'admin')
        
        # Generate unique order code
        order_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

        # Save order to database
        Order.objects.create(
            user=request.user,
            code=order_code,
            details=f"{product_name} - {delivery_method} - {payment_method}",
            status='waiting'
        )
        
        # Check for INJECTION ATTEMPT (VULNERABLE PATH)
        if product_name and ('{{' in product_name or '{%' in product_name):
            
            if is_admin_user:
                # Safe path for admin
                order_message = f"Your order for {product_name} has been successfully added!"
            else:
                # Vulnerable path for non-admin users
                try:
                    # --- CTF FIX: MOCKING THE VULNERABLE OBJECT PATH ---
                    mock_signer = Signer()

                    class MockStorage:
                        signer = mock_signer

                    class MockMessages:
                        storages = [MockStorage()]

                    # VULNERABILITY EXECUTION
                    template_string = f"Your order for {product_name} has been successfully added!"
                    vulnerable_template = Template(template_string)
                    context = Context({
                        'request': request,
                        'user': request.user,
                        'settings': settings,
                        'messages': MockMessages(),
                    })

                    order_message = vulnerable_template.render(context)
                    order_message = mark_safe(order_message)

                except Exception as e:
                    order_message = f"DTL Error: {e}"
                    print(f"SSTI Execution Error: {e}")
        
        # Safe path - normal order processing
        elif product_name:
            order_message = f"Your order for {product_name} has been successfully added!"
        
        # Get saved credit cards for POST response
        credit_cards = CreditCard.objects.filter(user=request.user).order_by('-created_at')
        
        # Return the page with success message
        return render(request, 'order.html', {
            'user': request.user,
            'order_message': order_message,
            'show_success': True,
            'delivery_method': delivery_method,
            'payment_method': payment_method,
            'credit_cards': credit_cards,  # Add this
        })
    
    # GET request - show empty form
    # Get saved credit cards for GET request
    credit_cards = CreditCard.objects.filter(user=request.user).order_by('-created_at')
    
    return render(request, 'order.html', {
        'user': request.user,
        'show_success': False,
        'credit_cards': credit_cards,  # Add this
    })