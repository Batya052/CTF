from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

# This form handles creating a new User, including password validation/confirmation
class RegistrationForm(UserCreationForm):
    # You can add extra fields here if your User model had them.
    # We add email because it's usually mandatory.
    email = forms.EmailField(required=True) 

    class Meta:
        # Use Django's built-in User model
        model = User 
        # Define the fields the form should display
        fields = ('username', 'email', 'password', 'password2') 
        # Note: UserCreationForm automatically handles password1 and password2