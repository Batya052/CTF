from django.shortcuts import render
from django.http import HttpResponse

def index(request):
    host = request.get_host().lower()  # ← make everything lowercase
    
    if 'reports.testing.com' in host:       # ← THIS catches docs.domain.com:80, :8000, etc.
        return render(request, "reports.html")
    elif 'testing.com' or '127.0.0.1' in host:          # ← THIS catches domain.com anything
        return render(request, "index.html")
    
    return HttpResponse("404 - Not Found", status=404)

def serve_image(request, name):
    from pathlib import Path
    BASE_DIR = Path(__file__).resolve().parent.parent
    file_path = BASE_DIR / "static" / name
    if file_path.exists():
        with open(file_path, "rb") as f:
            return HttpResponse(f.read(), content_type="image/png")
    return HttpResponse("Image not found", status=404)